# encoding=utf-8
__author__ = 'LoveLYJ'


class pLSA():
    def __init__(self):
        pass

    def fit(self):
        """
        训练pLSA
        [
            [token1, token2],
            [token1, token2, token3, token4]
        ]
        :return:
        """
        pass

    def transform(self):
        # no use
        pass

if __name__ == "__main__":
    pass
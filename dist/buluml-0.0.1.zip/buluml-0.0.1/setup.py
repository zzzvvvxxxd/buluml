# encoding=utf-8
__author__ = 'LoveLYJ'


from distutils.core import setup

setup(
    name='buluml',
    version='0.0.1',
    packages=['buluml'],
    url='https://github.com/zzzvvvxxxd/buluml',
    license='MIT',
    author='LoveLYJ',
    author_email='zzzvvvxxxd@gmail.com',
    description='bulu Dog\'s machine learning library'
)
